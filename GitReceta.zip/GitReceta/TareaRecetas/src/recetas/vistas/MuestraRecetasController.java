/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recetas.vistas;

import static java.awt.Event.INSERT;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import static java.sql.JDBCType.NULL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import recetas.modelo.Receta;

/**
 * FXML Controller class
 *
 * @author usuario
 */
public class MuestraRecetasController implements Initializable {

    private ObservableList<Receta> datosRecetas = FXCollections.observableArrayList();
    ConexionBD conex=new ConexionBD();
    @FXML
    private TableView<Receta> tablaRecetas;
    @FXML
    private TableColumn<Receta, String> columnaNombre;
    @FXML
    private TableColumn<Receta, String> columnaTiempo;
    @FXML
    private TableColumn<Receta, Number> columnaDificultad;
    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtTiempo;
    @FXML
    private TextField txtElaboracion;
    @FXML
    private TextField txtTipo;
    @FXML
    private DatePicker dpFechaAnotacion;
    @FXML
    private Slider sldDificultad;
    @FXML
    private ImageView ivImagen;
    @FXML
    private Label lblImagen;
    @FXML
    private Button btnEliminar;
    @FXML
    private Button btnNuevo;
    @FXML
    private Button btnModificar;
    @FXML
    private Button btnGuardar;
    @FXML
    private Button btnExaminar;
    @FXML
    private Receta recetaActual;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            cargarDatos();
            columnaNombre.setCellValueFactory(cellData -> cellData.getValue().nombreProperty());
            columnaTiempo.setCellValueFactory(cellData -> cellData.getValue().tiempoProperty());
            columnaDificultad.setCellValueFactory(cellData -> cellData.getValue().dificultadProperty());
            mostrarDetalles(null);
            tablaRecetas.getSelectionModel().selectedItemProperty().addListener(
                    (observable, valorViejo, valorNuevo) -> mostrarDetalles(valorNuevo));
            modoEdicion(false);
        } catch (IOException ex) {
            Logger.getLogger(MuestraRecetasController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

//    private void cargarDatos() {
//        datosRecetas.add(new Receta("1", "El madrino", 1972, "Francis Ford Poppola",
//                "Drama", LocalDate.of(1999, 2, 21), 4, "padrino.jpg"));
//        datosRecetas.add(new Receta("2", "Ciudadano Lane", 1941, "Torson Welles",
//                "Accion", LocalDate.of(2004, 3, 1), 3, "kane.jpg"));
//        datosRecetas.add(new Receta("3", "Salvad al soldado Brian", 1998, "Stefan Spilber",
//                "Comedia", LocalDate.of(2010, 12, 11), 5, "ryan.jpg"));
//        datosRecetas.add(new Receta("4", "El retorno del fredi", 1983, "Yorch Trucas",
//                "Drama", LocalDate.of(2016, 8, 4), 2, "terminator.jpg"));
//        tablaRecetas.setItems(datosRecetas);
//        System.out.println("Datos cargados " + datosRecetas.toString());
//    }

    private void cargarDatos() throws IOException {

        try {
            Connection con = conex.getConexion();
            if (con == null) {
                return;
            }
            Statement st = con.createStatement();
            String consulta = "Select id,nombre,tiempo,elaboracion,tipo,fechaAnotacion,dificultad,imagen from recetas";
            ResultSet rs = st.executeQuery(consulta);
            while (rs.next()) {
                Receta receta = new Receta(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getDate(6).toLocalDate(), rs.getInt(7), rs.getString(8));
                datosRecetas.add(receta);
            }
            tablaRecetas.setItems(datosRecetas);
        } catch (SQLException ex) {
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void mostrarDetalles(Receta receta) {
        if (receta != null) {
            this.txtNombre.setText(receta.getNombre());
            this.txtTiempo.setText(String.valueOf(receta.getTiempo()));
            this.txtElaboracion.setText(receta.getElaboracion());
            this.txtTipo.setText(receta.getTipo());
            this.dpFechaAnotacion.setValue(receta.getFechaAnotacion());
            this.sldDificultad.setValue(receta.getDificultad());
            Image imagen
                    = new Image(this.getClass().getResource("images/" + receta.getImagen()).toString());
            this.ivImagen.setImage(imagen);
            this.lblImagen.setText(receta.getImagen());

        } else {
            this.txtNombre.setText("");
            this.txtTiempo.setText("");
            this.txtElaboracion.setText("");
            this.txtTipo.setText("");
            this.dpFechaAnotacion.setValue(null);
            this.sldDificultad.setValue(0);
            Image imagen = new Image(this.getClass().getResource("images/generica.gif").toString());
            this.ivImagen.setImage(imagen);
            this.lblImagen.setText("");
        }
    }

    public void modoEdicion(Boolean editable) {
        if (editable == true) {
            this.txtNombre.setEditable(true);
            this.txtTiempo.setEditable(true);
            this.txtElaboracion.setEditable(true);
            this.txtTipo.setEditable(true);
            this.dpFechaAnotacion.setEditable(true);
            this.sldDificultad.setDisable(false);
            this.ivImagen.setDisable(false);

        } else {
            this.txtNombre.setEditable(false);
            this.txtTiempo.setEditable(false);
            this.txtElaboracion.setEditable(false);  
            this.txtTipo.setEditable(false);
            this.dpFechaAnotacion.setEditable(false);
            this.sldDificultad.setDisable(true);
            this.ivImagen.setDisable(true);
        }
    }
    
    @FXML
    public void guardarCambios() throws IOException, SQLException {
        recetaActual = tablaRecetas.getSelectionModel().getSelectedItem();
          
        Date fechaAux=Date.valueOf(LocalDate.of(
                   this.dpFechaAnotacion.getValue().getYear(),
                   this.dpFechaAnotacion.getValue().getMonth(),
                   this.dpFechaAnotacion.getValue().getDayOfMonth())); 
       
        int sldPunt=(int)this.sldDificultad.getValue();
        Connection conexion = null;
        Statement sentencia = null;
        String sql;
        try { 
            conexion = conex.conexionMySQL();
            sentencia = conexion.createStatement();
        if (recetaActual != null) { //se trata de una actualización
            sql="UPDATE RECETAS SET nombre = '"
                +this.txtNombre.getText()
                +"', tiempo = '"
                +this.txtTiempo.getText()
                +"', elaboracion = '"
                + this.txtElaboracion.getText()
                +"', tipo = '"
                +this.txtTipo.getText() 
                +"', fechaAnotacion = '"
                +fechaAux
                +"', dificultad = '"
                +sldPunt
                +"', imagen = '"
                +this.lblImagen.getText()
                +"', video = '' "
                + "WHERE id = '"+recetaActual.getId()+"';";
            int resultado=sentencia.executeUpdate(sql);
            System.out.println("Filas afectadas :" + resultado);
        } else {
            sql="INSERT INTO RECETAS VALUES(NULL,'"
                +this.txtNombre.getText()+"','"
                +this.txtTiempo.getText()+"','"
                +this.txtElaboracion.getText()+"','"
                +this.txtTipo.getText()+"','"
                +fechaAux+"','"
                +sldPunt+"','"
                +lblImagen.getText()+"','');";
            int resultado2= sentencia.executeUpdate(sql);
            System.out.println("Filas afectadas :" + resultado2);
            System.out.println();
        }
        System.out.println(sql);
        mostrarDetalles(recetaActual);
        modoEdicion(false);
        tablaRecetas.refresh();
       
        sentencia.close();
        conexion.close();
            
        } catch (IOException e1) {
            e1.printStackTrace();
        } catch (SQLException e2) {
            e2.printStackTrace();
        }catch (NumberFormatException e1) {
            System.out.println("Debe teclear un número");
         } 
    }


    @FXML
    public void manejarEliminar() {
        int selectedIndex = tablaRecetas.getSelectionModel().getSelectedIndex();
        System.out.println(selectedIndex);
        recetaActual = tablaRecetas.getSelectionModel().getSelectedItem();
        try { //Realizar la conexion         
            Connection conexion = conex.conexionMySQL(); //Preparamos la consulta          
            String sql = "DELETE FROM RECETAS WHERE id = '"+recetaActual.getId()+"';";
            Statement sentencia = conexion.createStatement();
            System.out.println(sql);
            int resultado = sentencia.executeUpdate(sql);
            System.out.println("Filas afectadas :" + resultado);
           
            sentencia.close();
            conexion.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException ex) {
            Logger.getLogger(MuestraRecetasController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
      
    @FXML
    public void manejarNuevo() {
        mostrarDetalles(null);
        tablaRecetas.getSelectionModel().clearSelection();
        modoEdicion(true);
    }

    @FXML
    public void manejarEditar() {
        modoEdicion(true);
    }

    @FXML
    public void manejarEscogerImagen() throws MalformedURLException {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Escoger imagen:");
        chooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.bmp", "*.png", "*.jpg", "*.gif"));
        File file = chooser.showOpenDialog(new Stage());
        if (file == null) {
            
            Image imagen
                    = new Image(this.getClass().getResource("images/generica.gif").toString());
            this.ivImagen.setImage(imagen);
            this.lblImagen.setText("generica.gif");          
        } else {
            String imagepath = file.toURI().toURL().toString();
            Image image = new Image(imagepath);
            this.ivImagen.setImage(image);
            this.lblImagen.setText(file.getName());
        }
       recetaActual.setImagen(this.lblImagen.getText());
    }
}
