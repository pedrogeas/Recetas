/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recetas.vistas;

import com.mysql.jdbc.Connection;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.DriverManager;

/**
 *
 * @author pedro
 */
class ConexionBD {
   
Connection miConexion;

    public Connection conexionMySQL() throws UnknownHostException, IOException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost/recetasbd";
            miConexion = (Connection) DriverManager.getConnection(url, "root", "");
            return miConexion;
        } catch (Exception ex) {
            System.out.println("Error al conectar a la BD" + ex.getMessage());
        }
        return miConexion;
    }

    public Connection getConexion() throws IOException {
        if (miConexion == null) {
            return this.conexionMySQL();
        }
        return miConexion;
    }
}