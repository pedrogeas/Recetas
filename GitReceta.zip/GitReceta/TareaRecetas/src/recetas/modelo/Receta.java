/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recetas.modelo;

import java.time.LocalDate;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author usuario
 */
public class Receta {
    private final StringProperty id;
    private final StringProperty nombre;
    private final StringProperty tiempo;
    private final StringProperty elaboracion;
    private final StringProperty tipo;
    private final ObjectProperty<LocalDate> fechaAnotacion;
    private final IntegerProperty dificultad;
    private final StringProperty imagen;
    
   

    public Receta(String id,String nombre, String tiempo, String elaboracion, String tipo, LocalDate fechaAnotacion, int dificultad, String imagen) {
        this.id = new SimpleStringProperty(id);
        this.nombre = new SimpleStringProperty(nombre);
        this.tiempo = new SimpleStringProperty(tiempo);
        this.elaboracion = new SimpleStringProperty(elaboracion);
        this.tipo = new SimpleStringProperty(tipo);
        this.fechaAnotacion = new SimpleObjectProperty<>(fechaAnotacion);
        this.dificultad = new SimpleIntegerProperty(dificultad);
        this.imagen = new SimpleStringProperty(imagen);
       
    }
    
    public void setId(String id) {
        this.id.set(id);
    }
    public StringProperty idProperty() {
        return id;
    }
     public String getId() {
        return id.get();
    }
     
    public void setTiempo(String tiempo) {
        this.tiempo.set(tiempo);
    }
    public StringProperty tiempoProperty() {
        return tiempo;
    }
    public String getTiempo() {
        return tiempo.get();
    }
    
    public void setElaboracion(String elaboracion) {
        this.elaboracion.set(elaboracion);
    }
    public StringProperty elaboracionProperty() {
        return elaboracion;
    }
    public String getElaboracion() {
        return elaboracion.get();
    }

    public void setTipo(String tipo) {
        this.tipo.set(tipo);
    }
       public String getTipo() {
        return tipo.get();
    }
     public StringProperty tipoProperty() {
        return tipo;
    }
    
    public void setFechaAnotacion(LocalDate fechaAnotacion) {
        this.fechaAnotacion.set(fechaAnotacion);
    }
    
    public LocalDate getFechaAnotacion() {
        return fechaAnotacion.get();
    }
     public ObjectProperty<LocalDate> fechaAnotacionProperty() {
        return fechaAnotacion;
    }
    
     
    public void setDificultad(Integer dificultad) {
        this.dificultad.set(dificultad);
    }
    public Integer getDificultad() {
        return this.dificultad.get();
    }
    public IntegerProperty dificultadProperty() {
        return dificultad;
    }
    
    public void setImagen(String imagen) {
        this.imagen.set(imagen);
    }
    public String getImagen() {
        return imagen.get();
    }
    public StringProperty imagenProperty() {
        return imagen;
    }
    
    public void setNombre(String nombre) {
        this.nombre.set(nombre);
    }

    public String getNombre() {
        return nombre.get();
    }

    public StringProperty nombreProperty() {
        return nombre;
    }
   
   
    
    
}
