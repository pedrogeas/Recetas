/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recetas;

import java.io.IOException;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author usuario
 */
public class Principal extends Application {
    private Stage escenarioPrincipal;
    private BorderPane layoutRaiz;
    
    
    
public void start(Stage escenarioPrincipal) {
this.escenarioPrincipal = escenarioPrincipal;
this.escenarioPrincipal.setTitle("Mis Recetas");
this.escenarioPrincipal.getIcons().add(new Image("/recetas/vistas/images/misRecetasLogo.jpg"));
iniciarVentanaRaiz();
mostrarRecetas();
        
        
        
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    public void iniciarVentanaRaiz() {
        try {
// Cargamos la interfaz desde el fichero fxml
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Principal.class.getResource("vistas/VentanaRaiz.fxml"));
            layoutRaiz = (BorderPane) loader.load();
// Mostramos la escena que contiene el layoutRaiz
            Scene scene = new Scene(layoutRaiz);
            escenarioPrincipal.setScene(scene);
            escenarioPrincipal.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void mostrarRecetas() {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(this.getClass().getResource("vistas/MuestraRecetas.fxml"));
            AnchorPane muestraReceta = (AnchorPane) loader.load();
// Fijamos la ventana que muestra las películas en el centro de la principal
            layoutRaiz.setCenter(muestraReceta);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}
